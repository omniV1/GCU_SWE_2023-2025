import React, {useState} from 'react';
import Card from './Card';
import './App.css';
const App = () => {
    const [albumList, setAlbumList] = useState([
        {
            artistId:0,
            artist:'Green Day',
            title: 'Insomniac',
            description:
            'Insomniac is the fourth studio album by the American rock band Green Day, released on October 10, 1995, by Reprise Records. It was recorded at Hyde Street in San Francisco, and the band prioritized high-energy takes during the recording sessions. Released as the follow-up to the band`s multi-platinum breakthrough Dookie, Insomniac featured a heavier, hardcore punk sound, with bleaker lyrics than its predecessor.[1][2] Lyrically, the album discusses themes such as alienation, anxiety, boredom, and drug use.[1] Insomniac also served as a reaction to many early fans who had turned their backs on the band after it achieved mainstream success with Dookie.[1]',
            year: 1995,
            image:
            'https://upload.wikimedia.org/wikipedia/en/thumb/b/bd/Green_Day_Insomiac.jpg/220px-Green_Day_Insomiac.jpg'
        },
        {
            artistId:1,
            artist:'Green Day',
            title: 'Dookie',
            description:
            'Dookie is the third studio album by the American rock band Green Day, released on February 1, 1994, by Reprise Records. The band`s major label debut and first collaboration with producer Rob Cavallo, it was recorded in late summer 1993 at Fantasy Studios in Berkeley, California. Written mostly by the singer and guitarist Billie Joe Armstrong, the album is largely based on his personal experiences and includes themes such as boredom, anxiety, relationships, and sexuality. It was promoted with four singles: `Longview` `Basket Case`, a re-recorded version of `Welcome to Paradise` which originally appeared on the band`s second studio album, 1991`s Kerplunk, and `When I Come Around`.',
            year: 1994,
            image:
            `https://upload.wikimedia.org/wikipedia/en/thumb/4/4b/Green_Day_-_Dookie_cover.jpg/220px-Green_Day_-_Dookie_cover.jpg`
        },
        {
            artistId:2,
            artist:'Green Day',
            title: 'Kerplunk',
            description:
            'Kerplunk (stylized as Kerplunk!)[nb 1] is the second studio album by the American rock band Green Day, released on December 17, 1991, by Lookout! Records. Following a US tour promoting their debut studio album 39/Smooth (1990), drummer John Kiffmeyer left to attend college and was replaced by Tré Cool, formerly of the Lookouts. By this stage, Green Day`s audience expanded to teenage',
            image:
            'https://upload.wikimedia.org/wikipedia/en/thumb/4/42/Green_Day_-_Kerplunk_cover.jpg/220px-Green_Day_-_Kerplunk_cover.jpg'
        },
    ]);
    const renderList = () => {
        return albumList.map((album) => {
            return (
                <Card
                    albumTitle={album.title}
                    albumDescription={album.description}
                    buttonText='OK'
                    image={album.image}
                />
            );
        });
    }
    
    return <div className="container">{renderList()}</div>;  
};

export default App;