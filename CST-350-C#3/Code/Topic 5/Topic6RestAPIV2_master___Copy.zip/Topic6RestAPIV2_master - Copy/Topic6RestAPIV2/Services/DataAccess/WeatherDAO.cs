﻿using System.Diagnostics;
using Topic6RestAPIV2.Models;
using Topic6RestAPIV2.Services.Data;

namespace Topic6RestAPIV2.Services.DataAccess
{
    public class WeatherDAO
    {
        // Step 3.
        /// <summary>
        /// Notice how this is an action using "Get"
        /// We want to get all weather data and pass
        /// to the Business Layer
        /// </summary>
        /// <returns></returns>
        public List<WeatherModel> GetAllWeatherData()
        {


            // Instantiate the Data Layer so we can get data
            WeatherData sampleData = new WeatherData();
            
            // Get the data and return it to the Businss Layer
            return sampleData.GetAllWeather();
        }



    }
}
