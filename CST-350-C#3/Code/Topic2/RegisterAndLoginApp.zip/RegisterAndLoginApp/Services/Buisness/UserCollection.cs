﻿using Microsoft.CodeAnalysis.CSharp.Syntax;
using RegisterAndLoginApp.Models;
namespace RegisterAndLoginApp.Services.Buisness
{
    public class UserCollection : IUserManager
    {
        private List<UserModel> _users;

        public UserCollection()
        {
            _users = new List<UserModel>();
            GenerateUserData();
        }

        private void GenerateUserData()
        {
            UserModel user1 = new UserModel();
            user1.Username = "Owen";
            user1.SetPassword("lindsey");
            user1.Groups = "Admin";
            AddUser(user1);

            UserModel user2 = new UserModel();
            user2.Username = "Sarah";
            user2.SetPassword("Lindsey");
            user2.Groups = "Admin, User";
            AddUser(user2);
        }

        public int AddUser(UserModel user)
        { 
            user.Id = _users.Count + 1;
            _users.Add(user);
            return user.Id;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public int CheckCredentials(string username, string password)
        {
            // Given a Username Password, find a matching user. Return the user`s ID
            foreach (UserModel user in _users)
            {
                if (user.Username == username && user.VerifyPassword(password))
                {
                    return user.Id;
                }
            }
            // No matches found, invalid login. 
            return 0;
        }

        public void DeleteUser(UserModel user)
        {
            _users.Remove(user);
        }

        public List<UserModel> GetAllUsers()
        {
            return _users;
        }
        /// <summary>
        /// Given an id number. Find the user with the matching id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public UserModel GetUserById(int id)
        {
            // use lambda expression to find the user with the matching ID
            /* lambda is just a way to write a quick, mini method without a name
             * It allows you to perform simple tasks without having to write a full method everytime
             */

            /* 1) Iterate over the list: The find method iterates through each UserModel object in the private users list
             * 2) we are going to apply condition for each user , the lambda expression u => u.id == id is evaluated. IF the u.id matches the id 
             * povided to the method, that Usermodel is condisdered a match
             * 3) return the first match: The Find method returns the first user that satisfies the condiditon. The condition is  u.Id == id
             * 4) Return null if no match: if no user in list has id then returns null 
             */

            return _users.Find(u => u.Id == id);
        }

        /// <summary>
        /// Find an existing user and update that user 
        /// </summary>
        /// <param name="user"></param>
        public void UpdateUser(UserModel user)
        {
            //Declare and initialize 
            int userId = -1;
            UserModel findUser = new UserModel();

            // Find matching id number
            //findUser variable will equal null if not found
            findUser = GetUserById(user.Id);

            // update exisiting user 
            if (findUser != null)
            {
                // Get the index of the user to update
                userId = _users.IndexOf(findUser);

                // update the user at this Id
                _users[userId] = user;

            }

            // find the user with the matching id and replace it 
            _users[_users.FindIndex(u => u.Id == user.Id)] = user;
        }

        // Method to generate and add fake user data to the 'user' list
        public void MakeSomeFakeData()
        {
            // Create and add some fake users to the list
            _users.Add(new UserModel { Id = 1, Username = "user1", PasswordHash = "password1" });
            _users.Add(new UserModel { Id = 2, Username = "user2", PasswordHash = "password2" });
            _users.Add(new UserModel { Id = 3, Username = "user3", PasswordHash = "password3" });
        }
    }
}