﻿using Microsoft.AspNetCore.Mvc;
using RegisterAndLoginApp.Models;
using RegisterAndLoginApp.Services.Buisness;

namespace RegisterAndLoginApp.Controllers
{
    public class UserController : Controller
    {
        // Instantiate the userCollection class and create an object of named users

        private static UserCollection users = new UserCollection();

        public IActionResult Index()
        {
            return View();
        }
        /// <summary>
        ///  This is a controller that will be called to process user login 
        /// </summary>
        /// <param name="loginViewModel"></param>
        /// <returns></returns>
        public IActionResult ProcessLogin(LoginViewModel loginViewModel)
        {
            // declare and initialize 
            int result = -1; 

            // is there a match 
            result = users.CheckCredentials(loginViewModel.Username, loginViewModel.Password);

            // we know the result will be 
            if (result >= 0)
            {
                // the result and return it with the "UserModel" 
                UserModel user = users.GetUserById(result);
                return View("LoginSuccess", user);
            }
                // There is no need for else 
                return View("LoginFailure");
            
        }
    }
}