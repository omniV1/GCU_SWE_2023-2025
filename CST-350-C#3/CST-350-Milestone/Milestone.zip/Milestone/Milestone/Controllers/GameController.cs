﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Milestone.Models;
using Milestone.Filters;
using Milestone.Models.GameModels;
using Milestone.Services.Business.Interfaces;

namespace Milestone.Controllers
{
    /// <summary>
    /// Controller responsible for handling Minesweeper game actions
    /// Requires an active session to access endpoints
    /// </summary>
    [SessionCheckFilter]
    public class GameController : Controller
    {
        private readonly IGameService _gameService;

        private readonly ILogger<GameController> _logger;


        /// <summary>
        /// Initializes a new instance of GameController
        /// </summary>
        /// <param name="gameService">Service for managing game operations</param>
        public GameController(
            IGameService gameService,

            ILogger<GameController> logger)  // Added logger to constructor
        {
            _gameService = gameService;

            _logger = logger;
        }

        /// <summary>
        /// Displays the initial game setup page
        /// </summary>
        /// <returns>View for starting a new game</returns>
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Processes a cell reveal action from the client
        /// </summary>
        /// <param name="request">Contains cell coordinates and game ID</param>
        /// <returns>JSON result containing revealed cells and game state</returns>
        [HttpPost]
        public IActionResult StartGame(string difficulty)
        {
            var board = _gameService.CreateGame(difficulty);
            return View("Game", board);
        }

        /// <summary>
        /// Processes a cell reveal action from the client
        /// </summary>
        /// <param name="request">Contains cell coordinates and game ID</param>
        /// <returns>JSON result containing revealed cells and game state</returns>
        [HttpPost]
        public IActionResult RevealCell([FromBody] CellRevealRequest request)
        {
            try
            {
                _logger.LogInformation($"Received cell reveal request: Row={request.Row}, Col={request.Col}, GameId={request.GameId}");

                if (request == null)
                {
                    return BadRequest("Invalid request data");
                }

                var result = _gameService.RevealCell(request.Row, request.Col, request.GameId);
                return Json(new
                {
                    revealedCells = result.RevealedCells,
                    isGameOver = result.IsGameOver,
                    isVictory = result.IsVictory
                });
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error in RevealCell: {ex.Message}");
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Displays a win or loss message 
        /// </summary>
        /// <param name="gameId"></param>
        /// <param name="isVictory"></param>
        /// <param name="score"></param>
        /// <returns></returns>
        /// <summary>
        /// Displays a win or loss message 
        /// </summary>
        [HttpPost("/Game/EndGame")]
        [HttpGet("/Game/EndGame")]
        public IActionResult EndGame([FromQuery] Guid gameId, [FromQuery] bool isVictory, [FromQuery] int score, [FromQuery] string time)
        {
            try
            {
                _logger.LogInformation($"EndGame called - Method: {Request.Method}");
                _logger.LogInformation($"Parameters - GameId: {gameId}, IsVictory: {isVictory}, Score: {score}, Time: {time}");

                // Validate game ID
                if (gameId == Guid.Empty)
                {
                    _logger.LogError("Invalid GameId provided");
                    return BadRequest("Invalid GameId");
                }

                var game = _gameService.GetGame(gameId);
                _logger.LogInformation($"Game lookup result: {(game != null ? "Found" : "Not Found")}");

                if (game == null)
                {
                    _logger.LogError($"Game not found for ID: {gameId}");
                    return NotFound($"Game {gameId} not found");
                }

                // Pass data to view
                ViewBag.FinalTime = time;
                _logger.LogInformation($"Rendering view for victory: {isVictory}");

                // Double check view exists
                var viewName = isVictory ? "Win" : "Loss";
                _logger.LogInformation($"Attempting to render view: {viewName}");

                try
                {
                    return View(viewName, game);
                }
                catch (Exception viewEx)
                {
                    _logger.LogError($"Error rendering view {viewName}: {viewEx.Message}");
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error in EndGame: {ex.Message}");
                _logger.LogError($"Stack trace: {ex.StackTrace}");
                throw; // Let the error handler catch this so we can see the full error
            }
        }

        private UserModel GetCurrentUser()
        {
            var userJson = HttpContext.Session.GetString("User");
            return ServiceStack.Text.JsonSerializer.DeserializeFromString<UserModel>(userJson);
        }

        /// <summary>
        /// Model for cell reveal request data from client
        /// </summary>
        public class CellRevealRequest
        {
            public int Row { get; set; }
            public int Col { get; set; }
            public Guid GameId { get; set; }
        }
    }
}