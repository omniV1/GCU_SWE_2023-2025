import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

const Index = () => {   
    return (
        <App/>
    );
}
export default Index;
ReactDOM.render(<App />, document.querySelector('#root'));