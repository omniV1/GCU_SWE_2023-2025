import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import dataSource from '../Services/dataSource';

const NewAlbum = () => {
 const navigate = useNavigate();
 
 // State for album data
 const [albumData, setAlbumData] = useState({
   title: '',
   artist: '',
   description: '',
   yearReleased: '',
   imageUrl: ''
 });

 // State for tracks
 const [tracks, setTracks] = useState([]);
 
 // State for new track form
 const [newTrack, setNewTrack] = useState({
   title: '',
   number: '',
   lyrics: '',
   videoUrl: ''
 });

 // Handle input changes for album data
 const handleInputChange = (e) => {
   const { name, value } = e.target;
   setAlbumData(prev => ({
     ...prev,
     [name]: value
   }));
 };

 // Add a new track to the tracks state
 const handleAddTrack = () => {
   if (newTrack.title && newTrack.number) {
     setTracks(prev => [...prev, { ...newTrack }]);
     // Reset the new track form
     setNewTrack({
       title: '',
       number: '',
       lyrics: '',
       videoUrl: ''
     });
   }
 };

 // Handle form submission
 const handleSubmit = async (e) => {
   e.preventDefault();
   try {
     // Create the album using the dataSource
     const albumResponse = await dataSource.createAlbum({
       ...albumData,
       tracks
     });
     console.log('Album created:', albumResponse);
     // Navigate back to the home page
     navigate('/');
   } catch (error) {
     console.error('Error creating album:', error);
     // Log the full error object for debugging
     console.error('Error creating album:', error.toJSON());
   }
 };

  return (
    <div className="container mt-4">
      <h2>Create New Album</h2>
      <form onSubmit={handleSubmit}>
        <div className="row">
          <div className="col-md-6">
            <div className="mb-3">
              <label className="form-label">Title</label>
              <input
                type="text"
                className="form-control"
                name="title"
                value={albumData.title}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Artist</label>
              <input
                type="text"
                className="form-control"
                name="artist"
                value={albumData.artist}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Year Released</label>
              <input
                type="number"
                className="form-control"
                name="yearReleased"
                value={albumData.yearReleased}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Image URL</label>
              <input
                type="url"
                className="form-control"
                name="imageUrl"
                value={albumData.imageUrl}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Description</label>
              <textarea
                className="form-control"
                name="description"
                value={albumData.description}
                onChange={handleInputChange}
                rows="3"
                required
              />
            </div>
          </div>

          <div className="col-md-6">
            <h3>Add Tracks</h3>
            <div className="mb-3">
              <label className="form-label">Track Number</label>
              <input
                type="number"
                className="form-control"
                value={newTrack.number}
                onChange={(e) => setNewTrack(prev => ({ ...prev, number: e.target.value }))}
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Track Title</label>
              <input
                type="text"
                className="form-control"
                value={newTrack.title}
                onChange={(e) => setNewTrack(prev => ({ ...prev, title: e.target.value }))}
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Lyrics</label>
              <textarea
                className="form-control"
                value={newTrack.lyrics}
                onChange={(e) => setNewTrack(prev => ({ ...prev, lyrics: e.target.value }))}
                rows="3"
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Video URL</label>
              <input
                type="url"
                className="form-control"
                value={newTrack.videoUrl}
                onChange={(e) => setNewTrack(prev => ({ ...prev, videoUrl: e.target.value }))}
              />
            </div>
            <button 
              type="button" 
              className="btn btn-secondary mb-3"
              onClick={handleAddTrack}
            >
              Add Track
            </button>

            {tracks.length > 0 && (
              <div className="mb-3">
                <h4>Added Tracks:</h4>
                <ul className="list-group">
                  {tracks.map((track, index) => (
                    <li key={index} className="list-group-item">
                      {track.number}. {track.title}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>

        <div className="mt-4">
          <button type="submit" className="btn btn-primary me-2">Create Album</button>
          <button 
            type="button" 
            className="btn btn-secondary"
            onClick={() => navigate('/')}
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default NewAlbum;