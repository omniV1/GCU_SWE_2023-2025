package com.owen;

import java.util.ArrayList; 
import java.sql.*; 



public class PetStoreDataAccessObject {
    static final String DATABASE_URL = "jdbc:mysql://localhost/my_pet_store";
    static final String USERNAME = "root";
    static final String PASSWORD = "root";


    public boolean addNewPet(Pet pet) {
        boolean isSuccess = false;
    
        String insertSQL = "INSERT INTO Pets (NAME, PRICE, DESCRIPTION, PET_CATEGORIES_ID) VALUES (?, ?, ?, ?)";
    
        // Open a connection
        try (Connection conn = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
            
            // Set parameters for the prepared statement
            pstmt.setString(1, pet.getName());
            pstmt.setDouble(2, pet.getPrice());
            pstmt.setString(3, pet.getDescription());
            pstmt.setInt(4, pet.getCategoryId());
    
            // Execute the insert command
            int rowsAffected = pstmt.executeUpdate();
            
            // If one or more rows are affected, the insert was successful
            if (rowsAffected > 0) {
                isSuccess = true;
            }
    
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    
        return isSuccess;
    }
    public boolean updatePet(Pet petToUpdate) {
        try (Connection conn = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("UPDATE Pets SET NAME = ?, PRICE = ?, DESCRIPTION = ?, PET_CATEGORIES_ID = ? WHERE ID = ?")) {
            
            // Set the parameters for the prepared statement based on the pet's details
            stmt.setString(1, petToUpdate.getName());
            stmt.setDouble(2, petToUpdate.getPrice());
            stmt.setString(3, petToUpdate.getDescription());
            stmt.setInt(4, petToUpdate.getCategoryId());
            stmt.setInt(5, petToUpdate.getId());
            
            // Execute the update
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }
    public ArrayList<Pet> searchPetsByKeyword(String keyword) {
        ArrayList<Pet> foundPets = new ArrayList<>();
    
        // Open a connection
        try (Connection conn = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(
                     "SELECT ID, NAME, PRICE, DESCRIPTION, PET_CATEGORIES_ID FROM Pets WHERE NAME LIKE ? OR DESCRIPTION LIKE ?")) {
    
            // Prepare the LIKE statement value with the keyword
            String likePattern = "%" + keyword + "%";
            pstmt.setString(1, likePattern);
            pstmt.setString(2, likePattern);
    
            // execute the query
            ResultSet resultSet = pstmt.executeQuery();
    
            // process the result set
            while (resultSet.next()) {
                Pet p = new Pet();
                p.setId(resultSet.getInt("ID"));
                p.setName(resultSet.getString("NAME"));
                p.setPrice(resultSet.getDouble("PRICE"));
                p.setDescription(resultSet.getString("DESCRIPTION"));
                p.setCategoryId(resultSet.getInt("PET_CATEGORIES_ID"));
    
                // add the pet to the return list
                foundPets.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    
        return foundPets;
    }
    
public Pet getPetById(int id) {
    Pet pet = null;
    
    String sqlString = "SELECT ID, NAME, PRICE, DESCRIPTION, PET_CATEGORIES_ID FROM Pets WHERE ID = ?";
    
    try (Connection conn = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
         PreparedStatement pstmt = conn.prepareStatement(sqlString)) {
        
        pstmt.setInt(1, id); // set the ID in the query
        
        ResultSet resultSet = pstmt.executeQuery();
        
        if (resultSet.next()) {
            pet = new Pet();
            pet.setId(resultSet.getInt("ID"));
            pet.setName(resultSet.getString("NAME"));
            pet.setPrice(resultSet.getDouble("PRICE"));
            pet.setDescription(resultSet.getString("DESCRIPTION"));
            pet.setCategoryId(resultSet.getInt("PET_CATEGORIES_ID"));
        }
        
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
    
    return pet;
}

    public ArrayList<Pet> getAllPets() {
        // create an empty set of Pets. Will be appended and returned.
        ArrayList<Pet> returnThese = new ArrayList<>();
        
        // Open a connection
        try (Connection conn = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
             Statement stmt = conn.createStatement()) {
            
            String sqlString = "SELECT ID, NAME, PRICE, DESCRIPTION, PET_CATEGORIES_ID FROM Pets";
            
            // execute query is for SELECT statements. There are other execute commands.
            // See documentation at https://docs.oracle.com/javase/tutorial/jdbc/basics/processingstatements.html
            ResultSet resultSet = stmt.executeQuery(sqlString);
            
            // result set is a list of items found in the database.
            // Loop through each item in the result set
            while (resultSet.next()) {
                // The following commented items can be optionally used for testing
                // System.out.println("ID: " + rs.getInt("ID"));
                // System.out.println("Name: " + rs.getString("NAME"));
                // System.out.println("Price: " + rs.getDouble("PRICE"));
                // System.out.println("Desc: " + rs.getString("DESCRIPTION"));

                // for each row in the result set, create a new pet
                Pet p = new Pet();
                p.setId(resultSet.getInt("ID"));
                p.setName(resultSet.getString("NAME"));
                p.setPrice(resultSet.getDouble("PRICE"));
                p.setDescription(resultSet.getString("DESCRIPTION"));
                p.setCategoryId(resultSet.getInt("PET_CATEGORIES_ID"));

                // add another pet to the return list
                returnThese.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        // returnThese should contain multiple pets.
        return returnThese;
    }
    
    public boolean deletePetByName(String petName) {
        boolean isDeleted = false;
        
        String deleteSQL = "DELETE FROM Pets WHERE NAME = ?";
    
        try (Connection conn = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(deleteSQL)) {
    
            stmt.setString(1, petName);
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                isDeleted = true;
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
        return isDeleted;
    }
}
