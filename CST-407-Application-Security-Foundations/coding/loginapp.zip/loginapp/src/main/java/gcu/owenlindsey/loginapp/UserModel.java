package gcu.owenlindsey.loginapp; // cspell:ignore owenlindsey


public class UserModel {
    
    private int id;
    private String username;
    private String password;
  

    public UserModel(int id, String username, String password) {
        this.id = id;
        this.username = username;
        this.password = password;
    }

    // default constructor
    public UserModel() {
        this.id = 0;
        this.username = "";
        this.password = "";
    }
    
    
    public int getId() {
        return id;
    }
    
    public String getUsername() {
        return username;
    }
    public String getPassword() {
        return password;
    }

    public void setId(int id) {
        this.id = id;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "UserModel [id=" + id + ", username=" + username + ", password=" + password + "]";
    }
    
    
}
