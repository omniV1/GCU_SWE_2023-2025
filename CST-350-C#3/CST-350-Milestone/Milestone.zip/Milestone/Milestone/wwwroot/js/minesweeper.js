﻿document.addEventListener('DOMContentLoaded', () => {
    /**
     * Calculates the final score based on time and remaining mines
     * @param {number} timeElapsed - Time taken in seconds
     * @param {number} remainingMines - Number of unflagged mines
     * @returns {number} - Calculated score
     */
    function calculateScore(timeElapsed, remainingMines) {
        // Basic score calculation - you can adjust this formula
        const baseScore = 1000;
        const timeDeduction = timeElapsed * 2;
        const mineBonus = remainingMines * 50;
        return Math.max(0, baseScore - timeDeduction + mineBonus);
    }
    /**
     * Game state variables initialization
     * - gameId: Unique identifier for current game session from server
     * - remainingMines: Tracks number of unflagged mines for win condition
     * - gameTimer: Reference to interval timer for cleanup
     * - startTime: Used for calculating elapsed time
     * - isGameOver: Prevents actions after game ends
     */
    const gameId = document.getElementById('gameBoard').dataset.gameId;
    let remainingMines = parseInt(document.getElementById('gameBoard').dataset.mines);
    let gameTimer;
    let startTime = new Date();
    let isGameOver = false;

    console.log('Game initialized with ID:', gameId, 'Mines:', remainingMines);

    /**
     * Timer Management Functions
     * startTimer: Begins the game timer, updating every second
     * updateTimer: Calculates and displays time in MM:SS format
     */
    function startTimer() {
        // Set interval to update timer display every second
        gameTimer = setInterval(updateTimer, 1000);
    }

    function updateTimer() {
        // Calculate minutes and seconds since game start
        const elapsed = Math.floor((new Date() - startTime) / 1000);
        // Format minutes with leading zero if needed
        const minutes = Math.floor(elapsed / 60).toString().padStart(2, '0');
        // Format seconds with leading zero if needed
        const seconds = (elapsed % 60).toString().padStart(2, '0');
        // Update timer display
        document.getElementById('timer').textContent = `${minutes}:${seconds}`;
    }

    /**
     * Updates the mine counter display showing remaining unflagged mines
     * Formats number with leading zeros for consistent display width
     */
    function updateMineCounter() {
        const counter = document.querySelector('.mine-counter');
        if (counter) {
            // Pad with zeros to ensure 3-digit display (e.g., 008)
            counter.textContent = remainingMines.toString().padStart(3, '0');
        }
    }

    /**
      * Gets all valid adjacent cells around a given position
      * Used for both peek functionality and chord reveals
      * @param {number} row - The row coordinate of center cell
      * @param {number} col - The column coordinate of center cell
      * @returns {Array} Array of valid adjacent cell elements
      */
    function getAdjacentCells(row, col) {
        const cells = [];
        // Check all 8 cells around the given position
        for (let i = -1; i <= 1; i++) {
            for (let j = -1; j <= 1; j++) {
                // Skip the center cell itself
                if (i === 0 && j === 0) continue;
                // Find adjacent cell using DOM query
                const adjacentCell = document.querySelector(
                    `.cell[data-row="${row + i}"][data-col="${col + j}"]`
                );
                // Only add cell if it exists (handles edge cases)
                if (adjacentCell) cells.push(adjacentCell);
            }
        }
        return cells;
    }

    /**
     * Handles right-click events for flagging potential mine locations
     * Prevents default context menu and updates mine counter
     * @param {Event} event - The right-click event to handle
     */
    function handleRightClick(event) {
        // Prevent browser context menu from appearing
        event.preventDefault();

        // Don't allow flagging after game is over
        if (isGameOver) return;

        const cell = event.target;
        console.log('Right clicked cell:', cell);

        // Can't flag already revealed cells
        if (cell.classList.contains('revealed')) {
            console.log('Cell is revealed, cannot flag');
            return;
        }

        // Toggle flag state
        if (cell.classList.contains('flagged')) {
            // Remove flag
            cell.classList.remove('flagged');
            cell.textContent = '';  // Clear flag emoji
            remainingMines++;  // Increment available mines
            cell.classList.remove('cell-pressed');  // Remove pressed effect
        } else if (remainingMines > 0) {
            // Add flag if we have mines remaining
            cell.classList.add('flagged');
            cell.textContent = '🚩';  // Add flag emoji
            remainingMines--;  // Decrement available mines
            cell.classList.add('cell-pressed');  // Add pressed effect
        }

        // Update the mine counter display
        updateMineCounter();
    }

    /**
     * Handles mousedown events for the peek functionality
     * Shows which cells would be revealed when holding right-click
     * @param {MouseEvent} event - The mousedown event
     */
    function handleMouseDown(event) {
        // Only process right mouse button clicks
        if (event.button === 2) {
            const cell = event.target;

            // Validate cell is eligible for peek:
            // - Must be revealed
            // - Must have a number
            // - Can't be a flag or bomb
            if (!cell.classList.contains('revealed') ||
                !cell.textContent ||
                cell.textContent === '🚩' ||
                cell.textContent === '💣') {
                return;
            }

            // Add visual feedback for the clicked number
            cell.classList.add('cell-pressed');

            const row = parseInt(cell.dataset.row);
            const col = parseInt(cell.dataset.col);
            // Get surrounding cells
            const adjacentCells = getAdjacentCells(row, col);

            // Add peek effect to eligible adjacent cells
            adjacentCells.forEach(adjCell => {
                if (!adjCell.classList.contains('flagged') &&
                    !adjCell.classList.contains('revealed')) {
                    adjCell.classList.add('peek');
                    adjCell.classList.add('cell-pressed');
                }
            });
        }
    }

    /**
     * Handles mouseup events for chord reveal functionality
     * A chord reveal occurs when a player right-clicks a revealed number 
     * where the adjacent flagged cells match the number's value
     * This automatically reveals all remaining adjacent cells
     * @param {MouseEvent} event - The mouseup event
     */
    async function handleMouseUp(event) {
        // Only process right mouse button releases (button code 2)
        if (event.button === 2) {
            const cell = event.target;

            // Clean up any existing peek effects from previous interactions
            // Both peek and cell-pressed classes provide visual feedback
            document.querySelectorAll('.peek, cell-pressed').forEach(cell => {
                cell.classList.remove('peek');
                cell.classList.remove('cell-pressed');
            });

            // Comprehensive validation for chord eligibility:
            // 1. Cell must be already revealed (showing a number)
            // 2. Must contain a non-empty value (has neighboring mines)
            // 3. Cannot be a flagged cell or revealed mine
            if (!cell.classList.contains('revealed') ||
                !cell.textContent ||
                cell.textContent === '🚩' ||
                cell.textContent === '💣') {
                return;
            }

            // Extract and parse cell position and value from DOM
            const row = parseInt(cell.dataset.row);
            const col = parseInt(cell.dataset.col);
            // The number shown represents adjacent mines
            const number = parseInt(cell.textContent);

            // Get all valid surrounding cells for the chord action
            const adjacentCells = getAdjacentCells(row, col);
            // Count how many adjacent cells are currently flagged
            // This determines if we can perform the chord reveal
            const flagCount = adjacentCells.filter(adjCell =>
                adjCell.classList.contains('flagged')).length;

            // Only proceed if the number matches exactly with placed flags
            // This is the core mechanic of chord revealing
            if (flagCount === number) {
                console.log('Chord revealing cells around', row, col);

                // Get list of cells that can be revealed:
                // - Not currently flagged (player marked as safe)
                // - Not already revealed (needs to be exposed)
                const cellsToReveal = adjacentCells.filter(adjCell =>
                    !adjCell.classList.contains('flagged') &&
                    !adjCell.classList.contains('revealed'));

                // Process each cell reveal sequentially
                // We use a for...of loop to handle async operations properly
                for (const adjCell of cellsToReveal) {
                    const adjRow = parseInt(adjCell.dataset.row);
                    const adjCol = parseInt(adjCell.dataset.col);

                    try {
                        // Make API call to server to reveal the cell
                        // Server handles game logic and returns updated state
                        const response = await fetch('/Game/RevealCell', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                Row: adjRow,
                                Col: adjCol,
                                GameId: gameId  // Unique identifier for this game session
                            })
                        });

                        // Check for HTTP errors in the response
                        if (!response.ok) {
                            throw new Error(`Server returned ${response.status}`);
                        }

                        // Parse and process the server's response
                        const result = await response.json();

                        // Update the game board based on server response
                        if (result.revealedCells) {
                            result.revealedCells.forEach(cellInfo => {
                                // Find the corresponding DOM element for each revealed cell
                                const targetCell = document.querySelector(
                                    `.cell[data-row="${cellInfo.row}"][data-col="${cellInfo.column}"]`
                                );
                                if (targetCell) {
                                    // Mark the cell as revealed in the UI
                                    targetCell.classList.add('revealed');

                                    // Update cell content based on what was revealed:
                                    if (cellInfo.isMine) {
                                        // If it's a mine, show the bomb emoji and add mine class
                                        targetCell.classList.add('mine');
                                        targetCell.textContent = '💣';
                                    } else if (cellInfo.neighborCount > 0) {
                                        // If it has adjacent mines, show the count
                                        targetCell.textContent = cellInfo.neighborCount;
                                        // Cells with 0 neighbors remain empty
                                    }
                                }
                            });

                            // Check if this reveal ended the game
                            if (result.isGameOver) {
                                isGameOver = true;
                                clearInterval(gameTimer);  // Stop the timer

                                // Calculate score based on time and remaining mines
                                const timeElapsed = Math.floor((new Date() - startTime) / 1000);
                                const score = calculateScore(timeElapsed, remainingMines);

                                // Get the final time from the timer display
                                const finalTime = document.getElementById('timer').textContent;

                                console.log('Game over detected, sending end game request...', {
                                    gameId,
                                    isVictory: result.isVictory,
                                    score,
                                    timeElapsed,
                                    finalTime
                                });

                                // Build the query string
                                const params = new URLSearchParams({
                                    gameId: gameId,
                                    isVictory: result.isVictory,
                                    score: score,
                                    time: finalTime
                                }).toString();

                                // Send the game end request
                                fetch(`/Game/EndGame?${params}`, {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json'
                                    }
                                })
                                    .then(response => {
                                        console.log('End game response:', response);
                                        if (response.ok) {
                                            window.location.href = `/Game/EndGame?${params}`;
                                        } else {
                                            console.error('Server returned error:', response.status);
                                            throw new Error('Server error');
                                        }
                                    })
                                    .catch(error => {
                                        console.error('Error ending game:', error);
                                    });

                                break;  // Exit the reveal loop
                            }
                        }
                    } catch (error) {
                        console.error('Error in chord reveal:', error);
                    }
                }
            }
        }
    }

    /**
     * Removes peek effect when mouse leaves a cell
     * This ensures visual feedback is cleaned up properly
     * even if the mouse leaves the cell abnormally
     */
    function handleMouseLeave() {
        // Find and remove all peek effects across the board
        // This prevents any peek effects from getting "stuck"
        document.querySelectorAll('.peek').forEach(cell => {
            cell.classList.remove('peek');
        });
    }

    /**
     * Handles regular left-click events for revealing cells
     * This is the primary game interaction for revealing new cells
     * Communicates with server to update game state and handle cascading reveals
     * @param {MouseEvent} event - The click event
     */
    async function handleCellClick(event) {
        try {
            // Prevent any actions if the game has ended
            if (isGameOver) return;

            const cell = event.target;
            // Skip if cell is already revealed or marked with a flag
            // This prevents unnecessary server calls
            if (cell.classList.contains('revealed') || cell.classList.contains('flagged')) return;

            // Extract cell coordinates from data attributes
            const row = parseInt(cell.dataset.row);
            const col = parseInt(cell.dataset.col);

            console.log('Clicking cell:', { row, col, gameId });

            // Send cell reveal request to server
            // Server handles game logic, mine checking, and cascade reveals
            const response = await fetch('/Game/RevealCell', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    Row: row,
                    Col: col,
                    GameId: gameId
                })
            });

            // Handle any HTTP errors from the server
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Server returned ${response.status}: ${errorText}`);
            }

            // Process the server's response
            const result = await response.json();
            console.log('Server response:', result);

            // Update the game board with newly revealed cells
            if (result.revealedCells) {
                result.revealedCells.forEach(cellInfo => {
                    // Find the DOM element for each cell to update
                    const targetCell = document.querySelector(
                        `.cell[data-row="${cellInfo.row}"][data-col="${cellInfo.column}"]`
                    );
                    if (targetCell) {
                        // Mark cell as revealed in UI
                        targetCell.classList.add('revealed');

                        // Update cell content based on what was revealed:
                        if (cellInfo.isMine) {
                            // Show mine and add mine class for styling
                            targetCell.classList.add('mine');
                            targetCell.textContent = '💣';
                        } else if (cellInfo.neighborCount > 0) {
                            // Show number of adjacent mines
                            // Zero neighbor cells remain empty for cleaner UI
                            targetCell.textContent = cellInfo.neighborCount;
                        }
                    }
                });

                // Check if this reveal ended the game
                if (result.isGameOver) {
                    isGameOver = true;
                    clearInterval(gameTimer);  // Stop the timer

                    // Calculate score based on time and remaining mines
                    const timeElapsed = Math.floor((new Date() - startTime) / 1000);
                    const score = calculateScore(timeElapsed, remainingMines);

                    // Get the final time from the timer display
                    const finalTime = document.getElementById('timer').textContent;

                    console.log('Game over detected, sending end game request...', {
                        gameId,
                        isVictory: result.isVictory,
                        score,
                        timeElapsed,
                        finalTime
                    });

                    // Build the query string
                    const params = new URLSearchParams({
                        gameId: gameId,
                        isVictory: result.isVictory,
                        score: score,
                        time: finalTime
                    }).toString();

                    // Send the game end request
                    fetch(`/Game/EndGame?${params}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    })
                        .then(response => {
                            console.log('End game response:', response);
                            if (response.ok) {
                                window.location.href = `/Game/EndGame?${params}`;
                            } else {
                                console.error('Server returned error:', response.status);
                                throw new Error('Server error');
                            }
                        })
                        .catch(error => {
                            console.error('Error ending game:', error);
                        });

                    return; // Add this to prevent further processing
                }
            }
        } catch (error) {
            console.error('Error handling cell click:', error);
        }
    }

    // Set up event listeners for all game cells
    // Each cell needs all these listeners to handle different interactions
    document.querySelectorAll('.cell').forEach(cell => {
        cell.addEventListener('click', handleCellClick);          // Regular cell reveal
        cell.addEventListener('contextmenu', handleRightClick);   // Flag placement
        cell.addEventListener('mousedown', handleMouseDown);      // Peek initiation
        cell.addEventListener('mouseup', handleMouseUp);          // Chord reveal
        cell.addEventListener('mouseleave', handleMouseLeave);    // Cleanup effects
    });

    // Global event listener for mouse leaving game board
    // This ensures no visual effects remain when mouse exits play area
    document.querySelector('.game-board').addEventListener('mouseleave', () => {
        document.querySelectorAll('.peek, .cell-pressed').forEach(cell => {
            cell.classList.remove('peek');
            cell.classList.remove('cell-pressed');
        });
    });

    // Global event listener for right mouse button release
    // Ensures cleanup of visual effects even if release happens outside board
    window.addEventListener('mouseup', (event) => {
        if (event.button === 2) {  // Right mouse button
            document.querySelectorAll('.peek, .cell-pressed').forEach(cell => {
                cell.classList.remove('peek');
                cell.classList.remove('cell-pressed');
            });
        }
    });

    // Initialize game state and UI elements
    startTimer();        // Begin tracking game time
    updateMineCounter(); // Show initial mine count
});