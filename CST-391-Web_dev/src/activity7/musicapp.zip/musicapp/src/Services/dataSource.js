import axios from 'axios';

const baseUrl = "http://localhost:3001/api"; // Added /api to match server routes

class DataSource {
  async getAllAlbums() {
    try {
      const response = await axios.get(`${baseUrl}/albums`);
      console.log("Albums fetched successfully:", response.data);
      return response.data;
    } catch (error) {
      console.error("Error fetching albums:", error);
      throw error;
    }
  }

  async searchAlbums(searchTerm) {
    try {
      const response = await axios.get(`${baseUrl}/albums/search?term=${searchTerm}`);
      return response.data;
    } catch (error) {
      console.error("Error searching albums:", error);
      throw error;
    }
  }
  async createAlbum(albumData) {
    try {
      const response = await axios.post(`${baseUrl}/albums`, albumData);
      return response.data;
    } catch (error) {
      console.error("Error creating album:", error);
      throw error;
    }
  }
  async getAlbumById(id) {
    try {
      const response = await axios.get(`${baseUrl}/albums/${id}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching album ${id}:`, error);
      throw error;
    }
  }

  async getAlbumTracks(albumId) {
    try {
      const response = await axios.get(`${baseUrl}/albums/${albumId}/tracks`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching tracks for album ${albumId}:`, error);
      throw error;
    }
  }
}

const dataSourceInstance = new DataSource();
export default dataSourceInstance;