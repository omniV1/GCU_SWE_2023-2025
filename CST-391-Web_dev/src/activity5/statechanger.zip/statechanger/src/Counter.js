import React, { useState } from 'react';
import'./Counter.css';

const Counter = (proprs) => {
    const [clicks, setClicks ] = useState(0);
    const [message, setMessage] = useState(proprs.title); 

    const addOneClick = () => {
        setClicks(clicks + 1);
    }; 
    const handleNewMessage = (event) => {
        setMessage(event.target.value);
    };

    return (
        <div className="one-box">
            <h1>{proprs.title}</h1>
            <h2>clicks: {clicks}</h2>
            <h3>message: {message}</h3>
            <input 
            type="text"
            value={message} 
            onChange={handleNewMessage} />
            <button onClick={addOneClick}>Click me</button>
            </div>
    );  
};
export default Counter; 