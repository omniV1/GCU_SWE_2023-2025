-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 14, 2023 at 02:11 AM
-- Server version: 5.7.24
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `christianorg`
--

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `donation_id` int(100) NOT NULL,
  `donation_date` date NOT NULL,
  `quantity` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `donation_categories`
--

CREATE TABLE `donation_categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `donation_centers`
--

CREATE TABLE `donation_centers` (
  `property_name` text NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `volunteers` text NOT NULL,
  `donation_centerid` int(11) NOT NULL,
  `donations_donation_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `donation_events`
--

CREATE TABLE `donation_events` (
  `donation_eventid` int(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `partners_partner_id` int(11) NOT NULL,
  `partners_partner_id1` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `donation_items`
--

CREATE TABLE `donation_items` (
  `clothes` varchar(100) NOT NULL,
  `toys` varchar(100) NOT NULL,
  `electronics` varchar(100) NOT NULL,
  `home_goods` varchar(100) NOT NULL,
  `perishable_food` text NOT NULL,
  `non_perishable_food` int(100) NOT NULL,
  `donated_itemid` int(11) NOT NULL,
  `donations_donation_id` int(100) NOT NULL,
  `donations_donation_id1` int(100) NOT NULL,
  `donation_categories_category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `donation_status`
--

CREATE TABLE `donation_status` (
  `status_id` int(11) NOT NULL,
  `donation_id` int(11) DEFAULT NULL,
  `status` enum('pending','processed','delivered') NOT NULL,
  `status_date` date NOT NULL,
  `comments` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `donors`
--

CREATE TABLE `donors` (
  `donor_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_info` varchar(255) DEFAULT NULL,
  `address` text,
  `donation_history` text,
  `type` varchar(50) DEFAULT NULL,
  `notes` text,
  `donation_events_donation_eventid` int(100) NOT NULL,
  `donations_donation_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `event_volunteers`
--

CREATE TABLE `event_volunteers` (
  `event_id` int(100) NOT NULL,
  `volunteer_id` int(11) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `donation_events_donation_eventid` int(100) NOT NULL,
  `donation_events_partners_partner_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE `partners` (
  `partner_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_info` varchar(255) DEFAULT NULL,
  `address` text,
  `type_of_partnership` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `notes` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `recipients`
--

CREATE TABLE `recipients` (
  `name` text NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `availability` text NOT NULL,
  `recipients_id` int(11) NOT NULL,
  `donations_donation_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `volunteers`
--

CREATE TABLE `volunteers` (
  `name` text NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `availability` text NOT NULL,
  `volunteer_id` int(11) NOT NULL,
  `event_volunteers_event_id` int(100) NOT NULL,
  `event_volunteers_volunteer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`donation_id`);

--
-- Indexes for table `donation_categories`
--
ALTER TABLE `donation_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `donation_centers`
--
ALTER TABLE `donation_centers`
  ADD PRIMARY KEY (`donation_centerid`,`donations_donation_id`),
  ADD KEY `fk_donation_centers_donations1_idx` (`donations_donation_id`);

--
-- Indexes for table `donation_events`
--
ALTER TABLE `donation_events`
  ADD PRIMARY KEY (`donation_eventid`,`partners_partner_id`,`partners_partner_id1`),
  ADD KEY `fk_donation_events_partners1_idx` (`partners_partner_id1`);

--
-- Indexes for table `donation_items`
--
ALTER TABLE `donation_items`
  ADD PRIMARY KEY (`donated_itemid`,`donations_donation_id`,`donations_donation_id1`,`donation_categories_category_id`),
  ADD KEY `fk_donation_items_donations1_idx` (`donations_donation_id1`),
  ADD KEY `fk_donation_items_donation_categories1_idx` (`donation_categories_category_id`);

--
-- Indexes for table `donation_status`
--
ALTER TABLE `donation_status`
  ADD PRIMARY KEY (`status_id`),
  ADD KEY `donation_id` (`donation_id`);

--
-- Indexes for table `donors`
--
ALTER TABLE `donors`
  ADD PRIMARY KEY (`donor_id`,`donation_events_donation_eventid`,`donations_donation_id`),
  ADD KEY `fk_donors_donation_events1_idx` (`donation_events_donation_eventid`),
  ADD KEY `fk_donors_donations1_idx` (`donations_donation_id`);

--
-- Indexes for table `event_volunteers`
--
ALTER TABLE `event_volunteers`
  ADD PRIMARY KEY (`event_id`,`volunteer_id`,`donation_events_donation_eventid`,`donation_events_partners_partner_id`),
  ADD KEY `fk_event_volunteers_donation_events1_idx` (`donation_events_donation_eventid`,`donation_events_partners_partner_id`);

--
-- Indexes for table `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`partner_id`);

--
-- Indexes for table `recipients`
--
ALTER TABLE `recipients`
  ADD PRIMARY KEY (`recipients_id`,`donations_donation_id`),
  ADD KEY `fk_recipients_donations1_idx` (`donations_donation_id`);

--
-- Indexes for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD PRIMARY KEY (`event_volunteers_event_id`,`event_volunteers_volunteer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `donation_id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `donation_categories`
--
ALTER TABLE `donation_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `donation_centers`
--
ALTER TABLE `donation_centers`
  MODIFY `donation_centerid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `donation_events`
--
ALTER TABLE `donation_events`
  MODIFY `donation_eventid` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `donation_items`
--
ALTER TABLE `donation_items`
  MODIFY `donated_itemid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `donation_status`
--
ALTER TABLE `donation_status`
  MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `donors`
--
ALTER TABLE `donors`
  MODIFY `donor_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `partners`
--
ALTER TABLE `partners`
  MODIFY `partner_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recipients`
--
ALTER TABLE `recipients`
  MODIFY `recipients_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `donation_centers`
--
ALTER TABLE `donation_centers`
  ADD CONSTRAINT `fk_donation_centers_donations1` FOREIGN KEY (`donations_donation_id`) REFERENCES `donations` (`donation_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `donation_events`
--
ALTER TABLE `donation_events`
  ADD CONSTRAINT `fk_donation_events_partners1` FOREIGN KEY (`partners_partner_id1`) REFERENCES `partners` (`partner_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `donation_items`
--
ALTER TABLE `donation_items`
  ADD CONSTRAINT `fk_donation_items_donation_categories1` FOREIGN KEY (`donation_categories_category_id`) REFERENCES `donation_categories` (`category_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_donation_items_donations1` FOREIGN KEY (`donations_donation_id1`) REFERENCES `donations` (`donation_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `donation_status`
--
ALTER TABLE `donation_status`
  ADD CONSTRAINT `donation_status_ibfk_1` FOREIGN KEY (`donation_id`) REFERENCES `donations` (`donation_id`);

--
-- Constraints for table `donors`
--
ALTER TABLE `donors`
  ADD CONSTRAINT `fk_donors_donation_events1` FOREIGN KEY (`donation_events_donation_eventid`) REFERENCES `donation_events` (`donation_eventid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_donors_donations1` FOREIGN KEY (`donations_donation_id`) REFERENCES `donations` (`donation_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `event_volunteers`
--
ALTER TABLE `event_volunteers`
  ADD CONSTRAINT `fk_event_volunteers_donation_events1` FOREIGN KEY (`donation_events_donation_eventid`,`donation_events_partners_partner_id`) REFERENCES `donation_events` (`donation_eventid`, `partners_partner_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `recipients`
--
ALTER TABLE `recipients`
  ADD CONSTRAINT `fk_recipients_donations1` FOREIGN KEY (`donations_donation_id`) REFERENCES `donations` (`donation_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD CONSTRAINT `fk_volunteers_event_volunteers1` FOREIGN KEY (`event_volunteers_event_id`,`event_volunteers_volunteer_id`) REFERENCES `event_volunteers` (`event_id`, `volunteer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
